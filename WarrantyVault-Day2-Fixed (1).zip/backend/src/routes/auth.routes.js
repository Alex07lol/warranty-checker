const express = require("express");
const rateLimit = require("express-rate-limit");
const auth = require("../middleware/auth");
const validate = require("../middleware/validate");
const controller = require("../controllers/auth.controller");
const {
  registerSchema,
  loginSchema,
  changePasswordSchema
} = require("../validators/auth.validator");

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false
});

router.post("/register", authLimiter, validate(registerSchema), controller.register);
router.post("/login", authLimiter, validate(loginSchema), controller.login);
router.post("/logout", auth, controller.logout);
router.get("/me", auth, controller.getMe);
router.put(
  "/change-password",
  auth,
  validate(changePasswordSchema),
  controller.changePassword
);

module.exports = router;
